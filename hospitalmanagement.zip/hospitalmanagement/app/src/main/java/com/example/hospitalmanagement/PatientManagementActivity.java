package com.example.hospitalmanagement;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.HashMap;
import java.util.Map;

public class PatientManagementActivity extends AppCompatActivity {
    private EditText etPatientName, etPatientAge, etPatientDisease, etPatientPhone;
    private LinearLayout patientListContainer;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_management);

        etPatientName = findViewById(R.id.etPatientName);
        etPatientAge = findViewById(R.id.etPatientAge);
        etPatientDisease = findViewById(R.id.etPatientDisease);
        etPatientPhone = findViewById(R.id.etPatientPhone);
        patientListContainer = findViewById(R.id.patientListContainer);
        db = FirebaseFirestore.getInstance();

        findViewById(R.id.btnAddPatient).setOnClickListener(v -> {
            String name = etPatientName.getText().toString().trim();
            String age = etPatientAge.getText().toString().trim();
            String disease = etPatientDisease.getText().toString().trim();
            String phone = etPatientPhone.getText().toString().trim();

            if (!name.isEmpty() && !age.isEmpty() && !disease.isEmpty() && !phone.isEmpty()) {
                Map<String, Object> patient = new HashMap<>();
                patient.put("name", name);
                patient.put("age", age);
                patient.put("disease", disease);
                patient.put("phone", phone);

                db.collection("patients").add(patient)
                        .addOnSuccessListener(documentReference -> {
                            Toast.makeText(this, "Patient added successfully", Toast.LENGTH_SHORT).show();
                            clearInputFields();
                            fetchPatients(); // Refresh the list
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to add patient", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "Please fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        // Fetch patients on activity load
        fetchPatients();
    }

    private void clearInputFields() {
        etPatientName.setText("");
        etPatientAge.setText("");
        etPatientDisease.setText("");
        etPatientPhone.setText("");
    }

    private void fetchPatients() {
        db.collection("patients").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                patientListContainer.removeAllViews(); // Clear the list before updating
                task.getResult().forEach(document -> {
                    String patientId = document.getId(); // Document ID for deletion
                    String name = document.getString("name");
                    String age = document.getString("age");
                    String disease = document.getString("disease");
                    String phone = document.getString("phone");

                    TextView patientView = new TextView(this);
                    patientView.setText(String.format("Name: %s, Age: %s, Disease: %s, Phone: %s", name, age, disease, phone));
                    patientView.setPadding(8, 8, 8, 8);
                    patientView.setTextSize(16);
                    patientView.setTextColor(getResources().getColor(android.R.color.black)); // Set text color to black

                    // Set a click listener to show the delete confirmation dialog
                    patientView.setOnClickListener(v -> {
                        showDeleteDialog(patientId); // Show the delete confirmation dialog when clicked
                    });

                    patientListContainer.addView(patientView);
                });
            } else {
                Toast.makeText(this, "Failed to fetch patients", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteDialog(String patientId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Patient")
                .setMessage("Are you sure you want to delete this patient?")
                .setPositiveButton("Yes", (dialog, which) -> {
                    deletePatient(patientId); // Delete the patient if confirmed
                })
                .setNegativeButton("No", null)
                .show();
    }

    private void deletePatient(String patientId) {
        db.collection("patients").document(patientId)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Patient deleted", Toast.LENGTH_SHORT).show();
                    fetchPatients(); // Refresh the list after deletion
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to delete patient", Toast.LENGTH_SHORT).show());
    }
}
