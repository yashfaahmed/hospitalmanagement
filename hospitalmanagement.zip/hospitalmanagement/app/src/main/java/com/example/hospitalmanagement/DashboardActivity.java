package com.example.hospitalmanagement;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;

public class DashboardActivity extends AppCompatActivity {
    private Button btnPatients, btnAppointments, btnStaff, btnLogout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dashboard);

        btnPatients = findViewById(R.id.btnPatients);
        btnAppointments = findViewById(R.id.btnAppointments);
        btnStaff = findViewById(R.id.btnStaff);
        btnLogout = findViewById(R.id.btnLogout);

        btnPatients.setOnClickListener(v -> startActivity(new Intent(this, PatientManagementActivity.class)));
        btnAppointments.setOnClickListener(v -> startActivity(new Intent(this, AppointmentActivity.class)));
        btnStaff.setOnClickListener(v -> startActivity(new Intent(this, StaffManagementActivity.class)));
        btnLogout.setOnClickListener(v -> {
            FirebaseAuth.getInstance().signOut();
            startActivity(new Intent(this, LoginActivity.class));
            finish();
        });
    }
}
