package com.example.hospitalmanagement;

import android.content.Intent;
import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;

public class MainActivity extends AppCompatActivity {
    private FirebaseAuth mAuth;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        mAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = mAuth.getCurrentUser();

        if (currentUser != null) {
            // User is logged in, go to DashboardActivity (or wherever appropriate)
            startActivity(new Intent(MainActivity.this, DashboardActivity.class));
        } else {
            // User is not logged in, go to LoginActivity
            startActivity(new Intent(MainActivity.this, SplashActivity.class));
        }

        finish(); // Finish MainActivity to prevent returning to it
    }
}
