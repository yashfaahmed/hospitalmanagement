package com.example.hospitalmanagement;

import android.app.AlertDialog;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Calendar;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Pattern;

public class AppointmentActivity extends AppCompatActivity {
    private EditText etPatientName, etPhoneNumber, etAppointmentDate;
    private Button btnScheduleAppointment;
    private LinearLayout appointmentListContainer;
    private FirebaseFirestore db;

    // Regular expression for validating a 11-digit phone number
    private static final Pattern PHONE_NUMBER_PATTERN = Pattern.compile("^[0-9]{11}$");

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_appointment);

        // Initialize UI elements
        etPatientName = findViewById(R.id.etPatientName);
        etPhoneNumber = findViewById(R.id.etPhoneNumber);
        etAppointmentDate = findViewById(R.id.etAppointmentDate);
        btnScheduleAppointment = findViewById(R.id.btnScheduleAppointment);
        appointmentListContainer = findViewById(R.id.appointmentListContainer);
        db = FirebaseFirestore.getInstance();

        // Add Date Picker integration
        etAppointmentDate.setOnClickListener(v -> showDatePickerDialog());

        // Schedule the appointment when the button is clicked
        btnScheduleAppointment.setOnClickListener(v -> {
            String name = etPatientName.getText().toString();
            String phone = etPhoneNumber.getText().toString();
            String date = etAppointmentDate.getText().toString();

            // Validate phone number
            if (!isValidPhoneNumber(phone)) {
                Toast.makeText(AppointmentActivity.this, "Phone number must be 11 digits", Toast.LENGTH_SHORT).show();
                return;
            }

            if (!name.isEmpty() && !phone.isEmpty() && !date.isEmpty()) {
                Map<String, Object> appointment = new HashMap<>();
                appointment.put("patientName", name);
                appointment.put("phone", phone);
                appointment.put("date", date);

                // Save appointment in Firestore
                db.collection("appointments").add(appointment)
                        .addOnSuccessListener(documentReference -> {
                            Toast.makeText(this, "Appointment scheduled", Toast.LENGTH_SHORT).show();
                            etPatientName.setText("");
                            etPhoneNumber.setText("");
                            etAppointmentDate.setText("");
                            fetchAppointments();
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to schedule appointment", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            }
        });

        // Fetch existing appointments
        fetchAppointments();
    }

    private void showDatePickerDialog() {
        final Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int day = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    String date = selectedYear + "-" +
                            String.format("%02d", selectedMonth + 1) + "-" +
                            String.format("%02d", selectedDay);
                    etAppointmentDate.setText(date);
                },
                year, month, day
        );
        datePickerDialog.show();
    }

    private void fetchAppointments() {
        db.collection("appointments").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                appointmentListContainer.removeAllViews(); // Clear previous appointments

                task.getResult().forEach(document -> {
                    String name = document.getString("patientName");
                    String phone = document.getString("phone");
                    String date = document.getString("date");
                    String docId = document.getId(); // Document ID for deletion

                    LinearLayout appointmentItem = new LinearLayout(this);
                    appointmentItem.setOrientation(LinearLayout.HORIZONTAL);
                    appointmentItem.setPadding(16, 16, 16, 16);

                    TextView appointmentText = new TextView(this);
                    appointmentText.setText(String.format("%s - Phone: %s on %s", name, phone, date));
                    appointmentText.setTextSize(16);
                    appointmentText.setTextColor(getResources().getColor(R.color.black));

                    // Set OnClickListener to show the delete dialog
                    appointmentItem.setOnClickListener(v -> showDeleteDialog(docId));

                    appointmentItem.addView(appointmentText);
                    appointmentListContainer.addView(appointmentItem);
                });
            } else {
                Toast.makeText(this, "Failed to fetch appointments", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void showDeleteDialog(final String documentId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Appointment")
                .setMessage("Are you sure you want to delete this appointment?")
                .setPositiveButton("Yes", (dialog, which) -> deleteAppointment(documentId))
                .setNegativeButton("No", null)
                .show();
    }

    private void deleteAppointment(String documentId) {
        db.collection("appointments").document(documentId)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Appointment deleted", Toast.LENGTH_SHORT).show();
                    fetchAppointments(); // Refresh the list
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to delete appointment", Toast.LENGTH_SHORT).show());
    }

    // Validate if the phone number is exactly 11 digits
    private boolean isValidPhoneNumber(String phone) {
        return PHONE_NUMBER_PATTERN.matcher(phone).matches();
    }
}
