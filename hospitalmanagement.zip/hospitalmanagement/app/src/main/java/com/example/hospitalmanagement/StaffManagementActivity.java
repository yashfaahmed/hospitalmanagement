package com.example.hospitalmanagement;

import android.os.Bundle;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.firestore.FirebaseFirestore;

import java.util.Map;

import java.util.HashMap;

public class StaffManagementActivity extends AppCompatActivity {
    private EditText etStaffName, etStaffRole;
    private TextView tvStaffList;
    private ImageButton btnClear;
    private FirebaseFirestore db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_staff_management);

        etStaffName = findViewById(R.id.etStaffName);
        etStaffRole = findViewById(R.id.etStaffRole);
        tvStaffList = findViewById(R.id.tvStaffList);
        btnClear = findViewById(R.id.btnClear);
        db = FirebaseFirestore.getInstance();


        findViewById(R.id.btnAddStaff).setOnClickListener(v -> {
            String name = etStaffName.getText().toString();
            String role = etStaffRole.getText().toString();

            if (!name.isEmpty() && !role.isEmpty()) {
                Map<String, Object> staff = new HashMap<>();
                staff.put("name", name);
                staff.put("role", role);

                db.collection("staff").add(staff)
                        .addOnSuccessListener(documentReference -> {
                            Toast.makeText(this, "Staff added", Toast.LENGTH_SHORT).show();
                            etStaffName.setText("");
                            etStaffRole.setText("");
                            fetchStaff();
                        })
                        .addOnFailureListener(e -> Toast.makeText(this, "Failed to add staff", Toast.LENGTH_SHORT).show());
            } else {
                Toast.makeText(this, "Fill all fields", Toast.LENGTH_SHORT).show();
            }
        });


        btnClear.setOnClickListener(v -> tvStaffList.setText("")); // Clear the staff list text


        fetchStaff();
    }


    private void fetchStaff() {
        db.collection("staff").get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                StringBuilder staffList = new StringBuilder("Staff Members:\n");
                tvStaffList.setText(""); // Clear any existing data before updating

                task.getResult().forEach(document -> {
                    String id = document.getId(); // Document ID
                    String name = document.getString("name");
                    String role = document.getString("role");
                    String staffEntry =  "Name: " + name + ", Role: " + role;


                    staffList.append(staffEntry).append("\n");


                    tvStaffList.setOnClickListener(v -> confirmAndDeleteStaff(id));
                });
                tvStaffList.setText(staffList.toString());
            } else {
                Toast.makeText(this, "Failed to fetch staff", Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void confirmAndDeleteStaff(String staffId) {
        new AlertDialog.Builder(this)
                .setTitle("Delete Staff")
                .setMessage("Are you sure you want to delete this staff member?")
                .setPositiveButton("Yes", (dialog, which) -> deleteStaff(staffId))
                .setNegativeButton("No", null)
                .show();
    }


    private void deleteStaff(String staffId) {
        db.collection("staff").document(staffId)
                .delete()
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(this, "Staff deleted", Toast.LENGTH_SHORT).show();
                    fetchStaff(); // Refresh the staff list
                })
                .addOnFailureListener(e -> Toast.makeText(this, "Failed to delete staff", Toast.LENGTH_SHORT).show());
    }
}
